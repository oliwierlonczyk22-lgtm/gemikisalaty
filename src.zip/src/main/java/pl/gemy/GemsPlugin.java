package pl.gemy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class GemsPlugin extends JavaPlugin implements Listener {

    private static final int SLOT = 13;

    private final Map<UUID, Gem> equipped = new HashMap<>();
    private final Set<Gem> dropped = EnumSet.noneOf(Gem.class);   // każdy gem może wypaść raz na serwer
    private final Map<UUID, Long> cooldownEnd = new HashMap<>();
    private final Set<UUID> airUsed = new HashSet<>();            // już użyto 2x spacji w tym skoku
    private final Set<UUID> managed = new HashSet<>();            // gracze, którym zarządzamy allowFlight
    private final Map<UUID, BukkitTask> shrinkTasks = new HashMap<>();
    final Map<UUID, Long> lifesteal = new HashMap<>();

    private final Random random = new Random();
    private NamespacedKey gemKey;
    private File dataFile;
    private YamlConfiguration data;
    private int counter = 0;

    static final class GemMenu implements InventoryHolder {
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        gemKey = new NamespacedKey(this, "gem");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        for (String s : data.getStringList("dropped")) {
            try { dropped.add(Gem.valueOf(s)); } catch (IllegalArgumentException ignored) {}
        }
        ConfigurationSection sec = data.getConfigurationSection("equipped");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                try { equipped.put(UUID.fromString(k), Gem.valueOf(sec.getString(k))); }
                catch (IllegalArgumentException ignored) {}
            }
        }
        dropped.addAll(equipped.values());

        getServer().getPluginManager().registerEvents(this, this);
        getCommand("gem").setExecutor((sender, cmd, label, args) -> {
            if (!(sender instanceof Player p)) { sender.sendMessage("Tylko dla graczy."); return true; }
            if (args.length == 2 && args[0].equalsIgnoreCase("give") && p.hasPermission("gems.admin")) {
                try {
                    Gem g = Gem.valueOf(args[1].toUpperCase());
                    dropped.add(g);
                    saveData();
                    p.getInventory().addItem(createItem(g));
                } catch (IllegalArgumentException ex) {
                    p.sendMessage(Component.text("Nie ma takiego gema.", NamedTextColor.RED));
                }
                return true;
            }
            openMenu(p);
            return true;
        });

        Bukkit.getScheduler().runTaskTimer(this, this::tick, 2, 2);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            resetScale(p);
            if (managed.contains(p.getUniqueId())) p.setAllowFlight(false);
        }
        saveData();
    }

    private void saveData() {
        data.set("dropped", dropped.stream().map(Enum::name).toList());
        data.set("equipped", null);
        equipped.forEach((u, g) -> data.set("equipped." + u, g.name()));
        try { data.save(dataFile); }
        catch (IOException ex) { getLogger().warning("Nie można zapisać data.yml: " + ex.getMessage()); }
    }

    // ------------------------------------------------------------ items

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    ItemStack createItem(Gem g) {
        ItemStack it = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta m = it.getItemMeta();
        m.displayName(line("Kryształ: " + g.displayName, g.color));
        m.lore(List.of(
                line("Cooldown: " + g.cooldown + "s", NamedTextColor.GRAY),
                line("Wpisz /gem, aby wyposażyć", NamedTextColor.DARK_GRAY),
                line("Użycie: 2x spacja", NamedTextColor.DARK_GRAY)));
        m.setEnchantmentGlintOverride(true);
        m.setMaxStackSize(1);
        m.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, g.name());
        it.setItemMeta(m);
        return it;
    }

    private Gem fromItem(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(gemKey, PersistentDataType.STRING);
        if (id == null) return null;
        try { return Gem.valueOf(id); } catch (IllegalArgumentException e) { return null; }
    }

    private void dropProtected(Location l, ItemStack it) {
        l.getWorld().dropItemNaturally(l, it, i -> {
            i.setInvulnerable(true);
            i.setUnlimitedLifetime(true);
            i.setGlowing(true);
        });
    }

    // ------------------------------------------------------------ drop z mobów

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        LivingEntity ent = e.getEntity();
        if (ent instanceof Player) return;
        Player killer = ent.getKiller();
        if (killer == null) return;
        if (random.nextDouble() >= getConfig().getDouble("drop-chance", 0.03)) return;

        List<Gem> available = Arrays.stream(Gem.values()).filter(g -> !dropped.contains(g)).toList();
        if (available.isEmpty()) return;

        Gem g = available.get(random.nextInt(available.size()));
        dropped.add(g);
        saveData();
        dropProtected(ent.getLocation(), createItem(g));
        killer.sendMessage(Component.text("✦ Wypadł kryształ: ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(g.displayName, g.color)));
    }

    // ------------------------------------------------------------ menu /gem

    private void openMenu(Player p) {
        GemMenu holder = new GemMenu();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Kryształy", NamedTextColor.DARK_PURPLE));
        holder.inv = inv;
        refresh(inv, p);
        p.openInventory(inv);
    }

    private void refresh(Inventory inv, Player p) {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta();
        pm.displayName(Component.text(" "));
        pane.setItemMeta(pm);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);

        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta im = info.getItemMeta();
        im.displayName(line("Jak to działa", NamedTextColor.LIGHT_PURPLE));
        im.lore(List.of(
                line("Połóż kryształ w środkowym slocie.", NamedTextColor.GRAY),
                line("Kliknij wyposażony kryształ, aby go zdjąć.", NamedTextColor.GRAY),
                line("Użycie abilitki: 2x spacja.", NamedTextColor.GRAY)));
        info.setItemMeta(im);
        inv.setItem(4, info);

        Gem g = equipped.get(p.getUniqueId());
        inv.setItem(SLOT, g == null ? null : createItem(g));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof GemMenu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        UUID id = p.getUniqueId();

        if (e.getClickedInventory() == top) {
            if (e.getRawSlot() != SLOT) return;
            Gem cur = equipped.get(id);
            if (cur != null) {
                equipped.remove(id);
                saveData();
                p.getInventory().addItem(createItem(cur)).values()
                        .forEach(rest -> dropProtected(p.getLocation(), rest));
            } else {
                Gem g = fromItem(e.getCursor());
                if (g == null) {
                    p.sendMessage(Component.text("Połóż tu kryształ.", NamedTextColor.RED));
                    return;
                }
                equipped.put(id, g);
                saveData();
                p.setItemOnCursor(null);
            }
        } else if (e.isShiftClick()) {
            Gem g = fromItem(e.getCurrentItem());
            if (g == null) return;
            if (equipped.containsKey(id)) {
                p.sendMessage(Component.text("Masz już wyposażony kryształ.", NamedTextColor.RED));
                return;
            }
            equipped.put(id, g);
            saveData();
            e.setCurrentItem(null);
        } else {
            return;
        }
        refresh(top, p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof GemMenu) e.setCancelled(true);
    }

    // ------------------------------------------------------------ 2x spacja

    @EventHandler
    public void onFlightToggle(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm != GameMode.SURVIVAL && gm != GameMode.ADVENTURE) return;
        UUID id = p.getUniqueId();
        Gem g = equipped.get(id);
        if (g == null || !e.isFlying()) return;

        // anty-latanie: blokujemy lot i wyłączamy możliwość 2x spacji do czasu wylądowania
        e.setCancelled(true);
        p.setFlying(false);
        p.setAllowFlight(false);
        airUsed.add(id);

        long now = System.currentTimeMillis();
        if (cooldownEnd.getOrDefault(id, 0L) > now) {
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1f);
            return;
        }
        cooldownEnd.put(id, now + g.cooldown * 1000L);
        p.playSound(p.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1f, 1.2f);
        g.ability.use(this, p);
    }

    private void tick() {
        boolean bar = (counter++ % 3) == 0;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            Gem g = equipped.get(id);
            GameMode gm = p.getGameMode();
            boolean normal = gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE;

            if (g == null || !normal) {
                if (managed.remove(id) && normal) p.setAllowFlight(false);
                continue;
            }
            managed.add(id);

            if (p.isOnGround()) {
                airUsed.remove(id);
                if (!p.getAllowFlight()) p.setAllowFlight(true);
            } else if (airUsed.contains(id) && p.getAllowFlight()) {
                p.setAllowFlight(false);
            }

            if (bar) actionBar(p, g, now);
        }
    }

    /** Action bar wyświetla się tuż nad paskiem XP. */
    private void actionBar(Player p, Gem g, long now) {
        long rem = cooldownEnd.getOrDefault(p.getUniqueId(), 0L) - now;
        Component c;
        if (rem <= 0) {
            c = Component.text("✦ " + g.displayName + " ", g.color)
                    .append(Component.text("GOTOWY", NamedTextColor.GREEN));
        } else {
            int sec = (int) Math.ceil(rem / 1000.0);
            double prog = 1.0 - (double) rem / (g.cooldown * 1000.0);
            int f = Math.max(0, Math.min(10, (int) (prog * 10)));
            String barStr = "█".repeat(f) + "░".repeat(10 - f);
            c = Component.text("✦ " + g.displayName + " ", g.color)
                    .append(Component.text(barStr + " " + sec + "s", NamedTextColor.RED));
        }
        p.sendActionBar(c);
    }

    // ------------------------------------------------------------ pomocnicze dla abilitek

    void shrink(Player p, double scale, int ticks) {
        AttributeInstance a = p.getAttribute(Attribute.SCALE);
        if (a == null) return;
        BukkitTask old = shrinkTasks.remove(p.getUniqueId());
        if (old != null) old.cancel();
        a.setBaseValue(scale);
        shrinkTasks.put(p.getUniqueId(), Bukkit.getScheduler().runTaskLater(this, () -> resetScale(p), ticks));
    }

    private void resetScale(Player p) {
        BukkitTask t = shrinkTasks.remove(p.getUniqueId());
        if (t != null) t.cancel();
        AttributeInstance a = p.getAttribute(Attribute.SCALE);
        if (a != null) a.setBaseValue(a.getDefaultValue());
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        if (e.getEntity().getScoreboardTags().contains("gem_proj")) e.blockList().clear(); // bez griefu
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        Long until = lifesteal.get(p.getUniqueId());
        if (until == null || until < System.currentTimeMillis()) return;
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        double max = a == null ? 20 : a.getValue();
        p.setHealth(Math.min(max, p.getHealth() + e.getFinalDamage() * 0.4));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        resetScale(p);
        lifesteal.remove(id);
        airUsed.remove(id);
        if (managed.remove(id)) p.setAllowFlight(false);
    }
}
