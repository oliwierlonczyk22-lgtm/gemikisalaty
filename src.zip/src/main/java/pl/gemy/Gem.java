package pl.gemy;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** 30 abilitek. Cooldowny: min 30s, max 60s. */
public enum Gem {

    DASH("Dash", NamedTextColor.AQUA, 30, (pl, p) -> {
        p.setVelocity(H.flat(p).multiply(2.2).setY(0.25));
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 25, .3, .1, .3, .02);
    }),

    DOUBLE_JUMP("Double Jump", NamedTextColor.WHITE, 30, (pl, p) -> {
        Vector v = H.flat(p).multiply(0.4).setY(1.0);
        p.setVelocity(v);
        p.setFallDistance(0);
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, .3, .1, .3, .02);
    }),

    ENDER_PEARL("Ender Pearl", NamedTextColor.DARK_PURPLE, 35, (pl, p) -> {
        p.launchProjectile(EnderPearl.class);
    }),

    SONIC_BOOM("Sonic Boom", NamedTextColor.DARK_AQUA, 45, (pl, p) -> {
        Location eye = p.getEyeLocation();
        Vector d = eye.getDirection();
        for (int i = 2; i <= 15; i += 3) {
            p.getWorld().spawnParticle(Particle.SONIC_BOOM, eye.clone().add(d.clone().multiply(i)), 1, 0, 0, 0, 0);
        }
        p.getWorld().playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f);
        for (LivingEntity le : H.nearby(p, 16)) {
            Vector to = le.getEyeLocation().toVector().subtract(eye.toVector());
            double along = to.dot(d);
            if (along > 0 && along < 15 && to.clone().subtract(d.clone().multiply(along)).length() < 1.6) {
                le.damage(12, p);
                le.setVelocity(d.clone().multiply(1.5).setY(0.4));
            }
        }
    }),

    SHRINK("Shrink", NamedTextColor.LIGHT_PURPLE, 50, (pl, p) -> {
        pl.shrink(p, 0.5, 200);
        H.fx(p, PotionEffectType.SPEED, 10, 1);
    }),

    FIREBALL("Fireball", NamedTextColor.RED, 40, (pl, p) -> {
        Fireball f = p.launchProjectile(Fireball.class, p.getEyeLocation().getDirection());
        f.setYield(2f);
        f.setIsIncendiary(false);
        f.addScoreboardTag("gem_proj");
    }),

    LIGHTNING("Lightning", NamedTextColor.YELLOW, 45, (pl, p) -> {
        Location t = H.target(p, 30);
        t.getWorld().strikeLightning(t);
    }),

    HEAL("Heal", NamedTextColor.GREEN, 50, (pl, p) -> {
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        double max = a == null ? 20 : a.getValue();
        p.setHealth(Math.min(max, p.getHealth() + 10));
        H.fx(p, PotionEffectType.REGENERATION, 5, 1);
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1, 0), 12, .4, .5, .4);
    }),

    SPEED_BOOST("Speed Boost", NamedTextColor.AQUA, 30, (pl, p) -> {
        H.fx(p, PotionEffectType.SPEED, 10, 2);
    }),

    STRENGTH_BURST("Strength Burst", NamedTextColor.DARK_RED, 40, (pl, p) -> {
        H.fx(p, PotionEffectType.STRENGTH, 10, 1);
    }),

    INVISIBILITY("Invisibility", NamedTextColor.GRAY, 45, (pl, p) -> {
        H.fx(p, PotionEffectType.INVISIBILITY, 12, 0);
    }),

    FREEZE_NOVA("Freeze Nova", NamedTextColor.AQUA, 45, (pl, p) -> {
        p.getWorld().spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 120, 3, .5, 3, .02);
        for (LivingEntity le : H.nearby(p, 6)) {
            H.fx(le, PotionEffectType.SLOWNESS, 5, 3);
            le.setFreezeTicks(le.getMaxFreezeTicks() + 100);
            le.damage(2, p);
        }
    }),

    SHOCKWAVE("Shockwave", NamedTextColor.GOLD, 40, (pl, p) -> {
        p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation(), 5, 1.5, .2, 1.5, 0);
        for (LivingEntity le : H.nearby(p, 6)) {
            H.push(le, p.getLocation(), 1.6, 0.6);
            le.damage(4, p);
        }
    }),

    BLINK("Blink", NamedTextColor.LIGHT_PURPLE, 30, (pl, p) -> {
        Location eye = p.getEyeLocation();
        Vector d = eye.getDirection();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, d, 10, FluidCollisionMode.NEVER, true);
        double dist = r == null ? 10 : Math.max(0, r.getHitPosition().distance(eye.toVector()) - 0.8);
        Location dest = eye.clone().add(d.clone().multiply(dist)).subtract(0, p.getEyeHeight(), 0);
        if (dest.getBlock().getType().isSolid()) dest.add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 40, .3, .5, .3, .5);
        p.teleport(dest);
        p.getWorld().spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 40, .3, .5, .3, .5);
    }),

    SHIELD("Shield", NamedTextColor.YELLOW, 50, (pl, p) -> {
        H.fx(p, PotionEffectType.ABSORPTION, 15, 2);
        H.fx(p, PotionEffectType.RESISTANCE, 5, 1);
    }),

    UPDRAFT("Updraft", NamedTextColor.WHITE, 35, (pl, p) -> {
        p.setVelocity(new Vector(0, 1.6, 0));
        H.fx(p, PotionEffectType.SLOW_FALLING, 8, 0);
    }),

    EXPLOSION("Explosion", NamedTextColor.RED, 55, (pl, p) -> {
        Location t = H.target(p, 25);
        t.getWorld().createExplosion(t, 3f, false, false, p);
    }),

    WIND_CHARGE("Wind Charge", NamedTextColor.WHITE, 30, (pl, p) -> {
        p.launchProjectile(WindCharge.class);
    }),

    ARROW_RAIN("Arrow Rain", NamedTextColor.GREEN, 55, (pl, p) -> {
        Location c = H.target(p, 30).add(0, 12, 0);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < 25; i++) {
            Location l = c.clone().add(r.nextDouble(-3, 3), 0, r.nextDouble(-3, 3));
            Arrow a = p.getWorld().spawnArrow(l, new Vector(0, -1, 0), 1.8f, 0.5f);
            a.setShooter(p);
            a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        }
    }),

    LIFESTEAL("Lifesteal", NamedTextColor.DARK_RED, 50, (pl, p) -> {
        pl.lifesteal.put(p.getUniqueId(), System.currentTimeMillis() + 10_000);
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1, 0), 10, .4, .5, .4);
    }),

    PULL("Pull", NamedTextColor.DARK_PURPLE, 35, (pl, p) -> {
        for (LivingEntity le : H.nearby(p, 10)) {
            Vector v = p.getLocation().toVector().subtract(le.getLocation().toVector());
            if (v.lengthSquared() < 1e-4) continue;
            le.setVelocity(v.normalize().multiply(1.2).setY(0.3));
        }
    }),

    RADAR("Radar", NamedTextColor.YELLOW, 40, (pl, p) -> {
        for (LivingEntity le : H.nearby(p, 30)) H.fx(le, PotionEffectType.GLOWING, 8, 0);
    }),

    FIRE_AURA("Fire Aura", NamedTextColor.GOLD, 45, (pl, p) -> {
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 80, 2.5, .5, 2.5, .02);
        H.fx(p, PotionEffectType.FIRE_RESISTANCE, 10, 0);
        for (LivingEntity le : H.nearby(p, 5)) {
            le.setFireTicks(100);
            le.damage(2, p);
        }
    }),

    SMOKE_BOMB("Smoke Bomb", NamedTextColor.DARK_GRAY, 45, (pl, p) -> {
        p.getWorld().spawnParticle(Particle.LARGE_SMOKE, p.getLocation().add(0, 1, 0), 100, 2, .8, 2, .02);
        for (LivingEntity le : H.nearby(p, 5)) H.fx(le, PotionEffectType.BLINDNESS, 5, 0);
        H.fx(p, PotionEffectType.INVISIBILITY, 4, 0);
        H.fx(p, PotionEffectType.SPEED, 4, 1);
    }),

    HASTE_RUSH("Haste Rush", NamedTextColor.YELLOW, 35, (pl, p) -> {
        H.fx(p, PotionEffectType.HASTE, 15, 2);
        H.fx(p, PotionEffectType.SPEED, 15, 0);
    }),

    FEATHER("Feather", NamedTextColor.WHITE, 30, (pl, p) -> {
        H.fx(p, PotionEffectType.SLOW_FALLING, 20, 0);
        H.fx(p, PotionEffectType.JUMP_BOOST, 20, 2);
    }),

    AQUA("Aqua", NamedTextColor.BLUE, 60, (pl, p) -> {
        H.fx(p, PotionEffectType.WATER_BREATHING, 30, 0);
        H.fx(p, PotionEffectType.DOLPHINS_GRACE, 30, 0);
        H.fx(p, PotionEffectType.NIGHT_VISION, 30, 0);
    }),

    GROUND_SLAM("Ground Slam", NamedTextColor.DARK_GREEN, 45, (pl, p) -> {
        p.setVelocity(new Vector(0, 1.0, 0));
        new BukkitRunnable() {
            int t = 0;
            boolean dived = false;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead()) { cancel(); return; }
                t++;
                if (t == 10) { p.setVelocity(new Vector(0, -2.5, 0)); dived = true; }
                if (dived) p.setFallDistance(0);
                if (dived && t > 12 && p.isOnGround()) {
                    p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation(), 6, 2, .2, 2, 0);
                    for (LivingEntity le : H.nearby(p, 5)) {
                        le.damage(8, p);
                        H.push(le, p.getLocation(), 1.0, 0.8);
                    }
                    cancel();
                }
                if (t > 80) cancel();
            }
        }.runTaskTimer(pl, 1, 1);
    }),

    POISON_CLOUD("Poison Cloud", NamedTextColor.DARK_GREEN, 50, (pl, p) -> {
        p.getWorld().spawn(p.getLocation(), AreaEffectCloud.class, c -> {
            c.setRadius(4f);
            c.setDuration(100);
            c.setSource(p);
            c.setColor(org.bukkit.Color.LIME);
            c.addCustomEffect(new PotionEffect(PotionEffectType.POISON, 80, 1), true);
        });
    }),

    ARROW_VOLLEY("Arrow Volley", NamedTextColor.GREEN, 40, (pl, p) -> {
        for (int i = -3; i <= 3; i++) {
            Vector d = p.getEyeLocation().getDirection().rotateAroundY(Math.toRadians(i * 7)).multiply(2.6);
            Arrow a = p.launchProjectile(Arrow.class, d);
            a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            a.setCritical(true);
        }
    });

    public interface Ability {
        void use(GemsPlugin plugin, Player player);
    }

    public final String displayName;
    public final NamedTextColor color;
    public final int cooldown; // sekundy
    public final Ability ability;

    Gem(String displayName, NamedTextColor color, int cooldown, Ability ability) {
        this.displayName = displayName;
        this.color = color;
        this.cooldown = cooldown;
        this.ability = ability;
    }

    static final class H {
        static Vector flat(Player p) {
            double y = Math.toRadians(p.getLocation().getYaw());
            return new Vector(-Math.sin(y), 0, Math.cos(y));
        }

        static void fx(LivingEntity e, PotionEffectType t, int sec, int amp) {
            e.addPotionEffect(new PotionEffect(t, sec * 20, amp));
        }

        static List<LivingEntity> nearby(Player p, double r) {
            return p.getNearbyEntities(r, r, r).stream()
                    .filter(e -> e instanceof LivingEntity && !(e instanceof ArmorStand))
                    .map(e -> (LivingEntity) e)
                    .toList();
        }

        static Location target(Player p, double range) {
            Location eye = p.getEyeLocation();
            RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range,
                    FluidCollisionMode.NEVER, true, 0.3, e -> e != p && e instanceof LivingEntity);
            if (r != null) return r.getHitPosition().toLocation(p.getWorld());
            return eye.clone().add(eye.getDirection().multiply(range));
        }

        static void push(LivingEntity e, Location from, double power, double y) {
            Vector v = e.getLocation().toVector().subtract(from.toVector()).setY(0);
            if (v.lengthSquared() < 1e-4) v = new Vector(0, 0, 0);
            else v.normalize().multiply(power);
            e.setVelocity(v.setY(y));
        }
    }
}
